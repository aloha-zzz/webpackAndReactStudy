function handleAddTodo(state=[],action) {
    switch (action.type){
        case 'ADD_TODO':
            let newState=state.slice();
            newState.push({
                content:action.content,
                id:action.id
            });
            return newState;
        default:
            return state;
    }
}

export default handleAddTodo;