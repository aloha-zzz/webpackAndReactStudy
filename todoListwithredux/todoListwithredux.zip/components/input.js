import React from 'react';

class Input extends React.Component{
    constructor(props){
        super(props);
    }


    render(){
        return(
            <div>
                <input ref={e=>{this.input=e}}/><button onClick={this.props.addTodo}>AddTodo</button>
            </div>
        )
    }
}
export default Input

