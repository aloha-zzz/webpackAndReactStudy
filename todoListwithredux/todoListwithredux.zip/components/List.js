import React from 'react';
import './List.css';

class List extends React.Component{
    render(){
        console.log(this.props.value);
        console.log('List------------')
        return(
            <ul>
                <li className="top">下面是todoList</li>
                {
                    this.props.value.map((item,index)=>{
                        return <li key={item.id}>{item.content}</li>
                    })
                }
            </ul>
        )

    }
}
export default List
