let id=0
export default function addTodo(content) {
    return{
        type:'ADD_TODO',
        id:id++,
        content
    }
}