import {connect} from 'react-redux';
import addTodo from './../actions/action'
import Input from './../components/input';


function mapDispatchToProps(dispatch) {
    return{
        addTodo:()=>dispatch(addTodo('aaaa'))
    }
}

const Inputwith=connect(
    ()=>({}),mapDispatchToProps
)(Input);

export default Inputwith;