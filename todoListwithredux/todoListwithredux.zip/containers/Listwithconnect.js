import {connect} from 'react-redux';
import List from './../components/List';


function mapStateToProps(state) {
    return{
        value:state
    }
}

const Listwith=connect(
    mapStateToProps,
    ()=>({})
)(List)

export default Listwith;